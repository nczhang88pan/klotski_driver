#include "pthread_impl.h"

int pthread_barrierattr_destroy(pthread_barrierattr_t *a)
{
	return 0;
}
