#include "pthread_impl.h"

int pthread_condattr_destroy(pthread_condattr_t *a)
{
	return 0;
}
