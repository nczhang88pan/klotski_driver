#include <semaphore.h>

int sem_destroy(sem_t *sem)
{
	return 0;
}
