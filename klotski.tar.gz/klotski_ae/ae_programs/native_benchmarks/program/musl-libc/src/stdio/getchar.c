#include <stdio.h>

int getchar(void)
{
	return fgetc(stdin);
}
