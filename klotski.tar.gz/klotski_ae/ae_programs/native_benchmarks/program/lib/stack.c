unsigned char _stack[0x400000] = {0};
